hexa-tales 独立游戏
在线试玩 https://wentaopeng714-cmd.github.io/floating-island-studio/hexa-tales.html
本地请通过 HTTP 服务器打开 index.html。
该文件夹包含完整游戏和 Three.js 依赖，可以独立部署。
